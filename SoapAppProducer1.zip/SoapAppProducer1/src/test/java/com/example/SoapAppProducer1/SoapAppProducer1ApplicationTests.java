package com.example.SoapAppProducer1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapAppProducer1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
