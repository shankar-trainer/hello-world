package com.cg.error;

public class CustomerException  extends Exception{

	public CustomerException(String s) {
	  super(s);
	  
	}
}
