package com.devskiller.calculator;

public class Calculator {

	public int add(int a, int b) {
		return 0;
	}

	public int subtract(int a, int b) {
		return 0;
	}

	public int multiply(int a, int b) {
		return 0;
	}

	public int divide(int a, int b) {
		return 0;
	}

}
