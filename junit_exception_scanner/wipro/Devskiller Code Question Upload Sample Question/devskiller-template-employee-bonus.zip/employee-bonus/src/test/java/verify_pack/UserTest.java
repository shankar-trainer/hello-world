package verify_pack;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;
import employeebonus.User;
public class UserTest {

    private HashMap<Integer, String> dobMap;
    private HashMap<Integer, Integer> salaryMap;

    @Before
    public void setUp() {
        // Initialize test data
        dobMap = new HashMap<>();
        dobMap.put(1, "01-01-1990"); // Age: 24
        dobMap.put(2, "15-06-1985"); // Age: 29
        dobMap.put(3, "20-09-1980"); // Age: 34
        dobMap.put(4, "01-01-1999"); // Age: 25
        dobMap.put(5, "01-01-1950"); // Age: 64

        salaryMap = new HashMap<>();
        salaryMap.put(1, 4000); // Salary: 4000
        salaryMap.put(2, 6000); // Salary: 6000
        salaryMap.put(3, 8000); // Salary: 8000
        salaryMap.put(4, 7000); // Salary: 7000
        salaryMap.put(5, 10000); // Salary: 10000
    }

    @Test
    public void testSalaryLessThan5000() {
        TreeMap<Integer, Integer> revisedSalaryMap = User.calculateRevisedSalary(dobMap, salaryMap);
        assertTrue(revisedSalaryMap.containsKey(1));
        assertEquals(100, (int) revisedSalaryMap.get(1));
    }

    @Test
    public void testAge29() {
        TreeMap<Integer, Integer> revisedSalaryMap = User.calculateRevisedSalary(dobMap, salaryMap);
        assertTrue(revisedSalaryMap.containsKey(2));
        assertEquals(1200, (int) revisedSalaryMap.get(2));
    }

    @Test
    public void testAge34() {
        TreeMap<Integer, Integer> revisedSalaryMap = User.calculateRevisedSalary(dobMap, salaryMap);
        assertTrue(revisedSalaryMap.containsKey(3));
        assertEquals(2400, (int) revisedSalaryMap.get(3));
    }

    @Test
    public void testAge25() {
        TreeMap<Integer, Integer> revisedSalaryMap = User.calculateRevisedSalary(dobMap, salaryMap);
        assertTrue(revisedSalaryMap.containsKey(4));
        assertEquals(200, (int) revisedSalaryMap.get(4));
    }

    @Test
    public void testAge64() {
        TreeMap<Integer, Integer> revisedSalaryMap = User.calculateRevisedSalary(dobMap, salaryMap);
        assertTrue(revisedSalaryMap.containsKey(5));
        assertEquals(200, (int) revisedSalaryMap.get(5));
    }
}
