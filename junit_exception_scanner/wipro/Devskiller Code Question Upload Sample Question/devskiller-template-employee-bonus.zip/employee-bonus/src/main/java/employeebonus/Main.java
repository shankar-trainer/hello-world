package employeebonus;

import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Step 1: Read Employee details
        HashMap<Integer, String> dobMap = new HashMap<>();
        HashMap<Integer, Integer> salaryMap = new HashMap<>();

       
        // Step 2: Call static method from User class to calculate revised salary
        TreeMap<Integer, Integer> revisedSalaryMap = User.calculateRevisedSalary(dobMap, salaryMap);
        // write the appropriate code for step2. below
        
        
        // Step 3: Display revised salary
        System.out.println("\nRevised Salary:");
        for (int id : revisedSalaryMap.keySet()) {
            System.out.println("Employee ID: " + id + ", Revised Salary: " + revisedSalaryMap.get(id));
        }
    }
}
