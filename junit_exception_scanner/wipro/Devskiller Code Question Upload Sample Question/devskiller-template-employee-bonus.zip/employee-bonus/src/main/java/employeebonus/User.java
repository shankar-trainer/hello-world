package employeebonus;

import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

public class User {
	
    public static TreeMap<Integer, Integer> calculateRevisedSalary(HashMap<Integer, String> dobMap, HashMap<Integer, Integer> salaryMap) {
       
        return null;
    }

    private static int calculateAge(String dob) {
        // Assuming the date format is "DD-MM-YYYY"
       return 0;
    }

    private static int calculateBonus(int age, int salary) {
       return 0;
    }
}

