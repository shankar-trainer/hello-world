package employeebonus;

import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

public class User {
    public static TreeMap<Integer, Integer> calculateRevisedSalary(HashMap<Integer, String> dobMap, HashMap<Integer, Integer> salaryMap) {
        TreeMap<Integer, Integer> revisedSalaryMap = new TreeMap<>();

        for (int id : dobMap.keySet()) {
            String dob = dobMap.get(id);
            int salary = salaryMap.get(id);

            int age = calculateAge(dob);
            int bonus = calculateBonus(age, salary);

            revisedSalaryMap.put(id, bonus);
        }

        return revisedSalaryMap;
    }

    private static int calculateAge(String dob) {
        // Assuming the date format is "DD-MM-YYYY"
        int dobYear = Integer.parseInt(dob.split("-")[2]);
        return 2014 - dobYear; // Year 2014 is taken as the reference year
    }

    private static int calculateBonus(int age, int salary) {
        if (salary < 5000) {
            return 100;
        }

        if (age >= 25 && age <= 30) {
            return (int) (salary * 0.2);
        } else if (age >= 31 && age <= 60) {
            return (int) (salary * 0.3);
        } else {
            return 200;
        }
    }
}

