package employeebonus;

import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Step 1: Read Employee details
        HashMap<Integer, String> dobMap = new HashMap<>();
        HashMap<Integer, Integer> salaryMap = new HashMap<>();

        System.out.println("Enter number of employees:");
        int numEmployees = scanner.nextInt();

        System.out.println("Enter employee details (id, DOB(dd-mm-yyyy), salary):");
        for (int i = 0; i < numEmployees; i++) {
            int id = scanner.nextInt();
            String dob = scanner.next();
            int salary = scanner.nextInt();

            dobMap.put(id, dob);
            salaryMap.put(id, salary);
        }

        // Step 2: Call static method from User class to calculate revised salary
        TreeMap<Integer, Integer> revisedSalaryMap = User.calculateRevisedSalary(dobMap, salaryMap);

        // Step 3: Display revised salary
        System.out.println("\nRevised Salary:");
        for (int id : revisedSalaryMap.keySet()) {
            System.out.println("Employee ID: " + id + ", Revised Salary: " + revisedSalaryMap.get(id));
        }
    }
}
