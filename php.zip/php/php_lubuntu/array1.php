<?php

var $ar1=

?>
