postman
http://localhost:9090/product/addProduct
"error": "Bad Request",

[
    {
        "productId": 11,
        "productName": "pant",
        "productCost": 2000.0,
        "productMfd": "2023-06-14",
        "orderSet": [
            {
                "orderId": 3,
                "orderName": "book",
                "orderLocation": "kolkotta"
            },
            {
                "orderId": 2,
                "orderName": "grocerry",
                "orderLocation": "chennai"
            },
            {
                "orderId": 1,
                "orderName": "pizza",
                "orderLocation": "delhi"
            }
        ]
    }
]