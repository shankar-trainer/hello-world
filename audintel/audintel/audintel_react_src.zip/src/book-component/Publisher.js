function Publisher(){
    return (
    <div className="bg-info border m-5 w-60 p-5">
    <h1>Publisher page</h1>
    </div>)
}
export default Publisher