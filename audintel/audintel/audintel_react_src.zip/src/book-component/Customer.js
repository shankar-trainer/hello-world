function Customer(){
    return (
    <div className="bg-info border m-5 w-60 p-5">
    <h1>Customer page</h1>
    </div>)
}
export default Customer