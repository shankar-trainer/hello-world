function Author(){
    return (
    <div className="border bg-info m-5 w-60 p-5">
    <h1>Author page</h1>
    </div>)
}
export default Author