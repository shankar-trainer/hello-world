import Layout from "./components/Layout"

const Employee=()=>{
    return(
        <>
        <Layout></Layout>
        </>
    )
}
export default Employee