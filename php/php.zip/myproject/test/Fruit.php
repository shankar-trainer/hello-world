<?php 
class Fruit{
    
}


?>