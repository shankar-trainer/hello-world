<?php

var $ar1=

?>
