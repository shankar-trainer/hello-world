
public class Ex6 {

	public static void main(String[] args) {
		
		
		int a=101;
		System.out.println(a);
		
		System.out.println((char)a);
		
		char b='A';
		System.out.println(b);
		System.out.println((int)b);
		
		//sysout -- ctrl+space
		
		
		
	}
}
