public class Hello {

	public static void main(String[] args) {

		System.out.println("hello world");
	   //sysout  -- ctrl +space 
		System.out.println("gteeting from java");
	}
}
