
public class Ex5 {

	public static void main(String[] args) {
		
		int x=10,y=20;
		String name="ram kumar";
		
		char code='a';
		
		System.out.println("no1 is "+x+"\nno2 is "+y+"\nname is "+name+"\ncode is "+code);

		System.out.printf("no1 is %d\nno2 is%d\nname is %s\ncode is %c",x,y,name,code);
		
	}
}

