package com.edu;

public class CastingTest1 {

	public static void main(String[] args) {
		byte b1 = 45;
		int a = b1;

		int p = 334;
		float f1 = p;// implicit casting or widenning
		
		
		System.out.println(a);
		System.out.println(f1);
		
		// explicit casting or narrowing 
		
		float f2=5665656.76766f;
		int k=(int) f2;
		System.out.println(k);
		
		
		

	}
}
