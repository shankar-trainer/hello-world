package com.edu;

public class Snippet {
	        byte b1=45;
	        int a=b1;
	
	    int p=334;
	  float f1=p;
	                                            
	
}

