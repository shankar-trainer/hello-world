package com.edu;

public interface Months {

	int Jan=1;
	int Feb=2;
	int March=3;
	int April=4;
	int May=5;
	int June=6;
	int July=7;
	int August=8;
	int Septemnber=9;
	int October=10;
	int November=11;
	int December=12;
	
}
