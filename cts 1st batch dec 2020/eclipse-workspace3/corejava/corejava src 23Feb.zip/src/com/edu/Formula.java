package com.edu;

public class Formula {

	final int  speed(int dist, int time){
		return (dist/time);
	}
	
	int formual2() {
		return 0;
	}
}

class MyFormula  extends Formula{
	
	@Override
//	int speed(int dist, int time) {
//	   return dist/3;
//	}
//	
}