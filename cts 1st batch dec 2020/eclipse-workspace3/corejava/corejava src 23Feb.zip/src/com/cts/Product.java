package com.cts;

 public class Product {

public 	int pid;
public 	String name;

protected float price;	
	
}
