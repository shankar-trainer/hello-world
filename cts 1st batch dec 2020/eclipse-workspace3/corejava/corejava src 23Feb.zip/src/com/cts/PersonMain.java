package com.cts;

public class PersonMain {

	public static void main(String[] args) {
		
		Person person1=new Customer1();
		person1.disp();
		
		person1=new Professor();
		person1.disp();
		
		person1=new Passenger();
		person1.disp();
		
	}
}
