package com.cts;

public class ProductMain {

	public static void main(String[] args) {
		Product product=new Product();
		product.pid=877887;
		product.name="java book";
		product.price=787.666f;
		
	}
}
