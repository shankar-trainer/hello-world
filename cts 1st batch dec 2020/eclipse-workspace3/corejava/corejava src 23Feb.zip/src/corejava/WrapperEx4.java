package corejava;

public class WrapperEx4 {

	public static void main(String[] args) {

		Integer p = 4454554;// boxing

		int p1 = p; // unboxing

		// autoboxing --- boxing +unboxing

		String s = "545454";

		int parseInt = Integer.parseInt(s);

		float f1 = Float.parseFloat("565456");
		double d1 = Double.parseDouble("565456");

		System.out.println(f1);
		
		
		String s11=Integer.toString(56656);
		
		
		
	}
}
