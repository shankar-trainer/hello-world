package corejava;

public class WrapperEx2 {

	public static void main(String[] args) {

		int p=87878;
		
		int k=0b1010;// binary no 
		
		int m=0x1234abc; // hexa decimal
		
		int s=0123;// octal no 
		
		System.out.println(p);
		System.out.println(k);
		System.out.println(m);
		System.out.println(s);
		
		
		
		
		

	}
}
