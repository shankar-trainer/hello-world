package corejava;

public class TestStudent {

	public static void main(String[] args) {
		
		Student student=new Student();
		//student.roll=999;
		
		
		
	}
}
