
public class Ex2 {

	public static void main(String[] args) {
		int x=9;
		int res=9/2;
		System.out.println(res);
		
		System.out.println(2/9);
		
		//System.out.println(2/0);
		
		int a=12,b=20;
		
		System.out.println("no1 is "+a);
		System.out.println("no2 is "+b);
		
		System.out.println("\nno1 is "+a+"\nno2 is "+b);
		
		
		
		
		
		
	}
}
