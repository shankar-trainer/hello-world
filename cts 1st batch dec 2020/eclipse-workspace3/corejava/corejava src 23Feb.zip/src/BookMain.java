
public class BookMain {

	public static void main(String[] args) {
		
		Book b1=new Book();
		
		System.out.println(b1.getIsbn());
		System.out.println(b1.getBname());
	}

}
