
public class Test2 {

	int id;// instance variable

	void disp(int x, String s) {
		
	}
	
	
	public static void main(String[] args) {
		int p;// local variable any defaul value
		
		Test2 test2=new Test2();
		
		System.out.println(test2.id);
		//	System.out.println(p);//  error if not initialised
		
		
		
		Integer p1=9999;
		Integer p2=null;
		
		String s=null;
	}
}
