import logo from './logo.svg';
import './App.css';

function App() {
 var x=100;
 var y=200;
  return( 
  <div class='style1'>
  <h1>hello world</h1>
  <p>No1 is {x}</p>
  <p>No2 is {y}</p>
  <p>Addition is {x+y}</p>
  </div>
  ) 
}

export default App;
