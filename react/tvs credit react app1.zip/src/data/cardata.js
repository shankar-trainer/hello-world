const   cardata=[
  {"carid":787887,"carmodel":'mustag',"carmfd":'june 2022'},
  {"carid":787888,"carmodel":'fortuner',"carmfd":'march 2020'},
  {"carid":787889,"carmodel":'jaguar',"carmfd":'feb 2021'},
  {"carid":787880,"carmodel":'honda city',"carmfd":'july 2020'},
  {"carid":787881,"carmodel":'alto',"carmfd":'dec 2020'},
  {"carid":787882,"carmodel":'swift desire',"carmfd":'aug 2021'},
  {"carid":787883,"carmodel":'maruti',"carmfd":'sep 2020'},
  {"carid":787884,"carmodel":'celario',"carmfd":'jan 2023'}
]
export default cardata;