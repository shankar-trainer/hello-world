export default function GuestGreeting(props){
  return <h1>Guest Greeting</h1>
}