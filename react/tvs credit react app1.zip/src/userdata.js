const  userdata={
    "id":10001,
    "name":'ramesh kumar',
    "salary":20000
}

export default userdata;