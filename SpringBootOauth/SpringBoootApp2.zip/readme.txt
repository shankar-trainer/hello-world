ORM -- object relational mapping 

Employee class ------->Employee table(id,name,salary)
 id,name,salary 
               jpa  api --- save(object) 
                            update(object)
                            delete(object)
                            find(id)
                 
        mapped using orm tool 
        orm -- hibernate core, jpa 
        
     jpa -- spring 
       
       spring data jpa 
         
         annotation --
         
                     @controller -- controller layer -- json data -- client(react,angular) 
                         |
                         v 
                     @service    -- service layer -- service to the client
                         |
                         V
                     @repository -- dao layer    
                     
                     

         
