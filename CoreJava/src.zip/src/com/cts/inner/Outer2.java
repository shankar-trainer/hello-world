package com.cts.inner;

public class Outer2 {

	  void disp() {
		  
		  class Hello{
			  
		  }
	  }
	
	public static void main(String[] args) {
		
	}
}
