package com.cts;

 public class Account {
 public  int accountId;
 public String accountName;
	
}
