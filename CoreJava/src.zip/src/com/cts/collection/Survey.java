package com.cts.collection;

public class Survey {

	private int surveyId;
	private String surveyName;
	private String surveyLocation;

	public int getSurveyId() {
		return surveyId;
	}
	public void setSurveyId(int surveyId) {
		this.surveyId = surveyId;
	}
	public String getSurveyName() {
		return surveyName;
	}
	public void setSurveyName(String surveyName) {
		this.surveyName = surveyName;
	}
	public String getSurveyLocation() {
		return surveyLocation;
	}
	public void setSurveyLocation(String surveyLocation) {
		this.surveyLocation = surveyLocation;
	}
}

