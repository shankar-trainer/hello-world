
public class Test2 {

	public static void main(String[] args) {
		int x=10;
		System.out.println(x/2);
		System.out.println(x/5);
		System.out.println(x/6);
		System.out.println(x/7);
		System.out.println(x/10);
		System.out.println(x/11);
		System.out.println(x/12);
		
		
		
	}
}
