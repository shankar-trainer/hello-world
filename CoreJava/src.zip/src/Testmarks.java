
public class Testmarks {

	public static void main(String[] args) {
		marks marks1=new marks();
		marks1.setRegnum(777667);
		marks1.setMarksInEng(67);
		marks1.setMarksInMaths(88);
		marks1.setMarksInScience(79);

		System.out.println(marks1);
	
	}
}
