
public class Test1 {

	//main   -- ctrl+space
	
	public static void main(String[] args) {
		//sysout -- ctrl+space 
		int x=10,y=20;
		int z=x+y;
		
		System.out.println("x is "+x+"\ny is "+y+"\nsum is "+z);
		System.out.println("------------------");
		System.out.println("x is "+x);
		System.out.println("y is "+x);
		System.out.println("sum is "+x);
	}
}
