
public class StringProgram8 {

	public static void main(String[] args) {

		
		String var1="we are learning  java";
		String var2="we-are-learning-java";
	
		System.out.println(var1.matches(var2));
	
	
	}
}
