
public class Speech {

	private int speechId;
	private String  speechName;
	private int speechDuration;
	
	public int getSpeechId() {
		return speechId;
	}
	public void setSpeechId(int speechId) {
		this.speechId = speechId;
	}
	public String getSpeechName() {
		return speechName;
	}
	public void setSpeechName(String speechName) {
		this.speechName = speechName;
	}
	public int getSpeechDuration() {
		return speechDuration;
	}
	public void setSpeechDuration(int speechDuration) {
		this.speechDuration = speechDuration;
	}
}
