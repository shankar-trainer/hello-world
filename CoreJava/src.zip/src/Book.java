
public class Book {

	private int isbn;
	private String bname;
	private float bcost;
	private String author;

	public int getIsbn() {
		return isbn;
	}

	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public float getBcost() {
		return bcost;
	}

	//public
	void setBcost(float bcost) {
		this.bcost = bcost;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

}
