
public class Test6 {

	public static void main(String[] args) {
		
		int a=10;
		System.out.println(a++);//increment but not assigned  
		                        // post increment 
		System.out.println(a);
		
		int b=20;
		System.out.println(++b);//  ++b   incremented and assigned  
		                        // pre increment
	}
}
