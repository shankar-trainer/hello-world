
public class WarppeerDemo2 {

	public static void main(String[] args) {
	
		String s="123";
		int p1=Integer.parseInt(s);
		
		String s2="5665.56f";
		
		float f1=Float.parseFloat(s2);
		
	String s1=	Integer.toString(-1233);
	String s22=	Integer.toBinaryString(1233);
	String s3=	Integer.toOctalString(1233);
	String s4=	Integer.toHexString(1233);
	String s5=	Integer.toUnsignedString(-1233);
	String s6=	Integer.toUnsignedString(1233);
	
	System.out.println(s1);
	System.out.println(s22);
	System.out.println(s3);
	System.out.println(s4);
	System.out.println(s5);
	System.out.println(s6);
	
	int p=0123;
	int p2=0x5665;
	int p3=0b10;
	
	
		
		
	}
}
