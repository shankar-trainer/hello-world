
public class StringProgram2 {

	public static void main(String[] args) {
		
		String s1="abc";// immutable // refers obj1
		String s2="abc";// refers obj1
		String s3="abc";// refers obj1
		                 // string pool 
		
	 s1="abcd";  // refers obj2
	 //  one ref variable and two objects 
	 
	
		
		
	}
}
