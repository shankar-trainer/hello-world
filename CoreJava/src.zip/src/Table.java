
public class Table {

	public static void main(String[] args) {
		
		int counter=1;
	     int no1=5;
	     
	     while(counter<=10) {
	    	 System.out.println(counter*no1);
	        counter++;
	     }
	
	}
}
