
public class Circle {

	public static void main(String[] args) {
		//int p1=776.656;// error 
		
		double d1=565;
		System.out.println(d1/2);
		
		float p1=878878;
		
		System.out.println(p1/2);
		
		float p2=56.45F;
		
		float radius=45.6f;
		
		float area=3.14f*radius*radius;
		float circumference=2*3.14f*radius;
		
		
		System.out.println("circle area is "+area);
		System.out.println("circle circumference is "+circumference);
		
		
		
	}
}
