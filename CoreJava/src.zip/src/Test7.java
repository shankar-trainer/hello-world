
public class Test7 {

	public static void main(String[] args) {
		
		//System.out.println(10/0);
		System.out.println(10.0/0);
		
		byte b1= 127;
		//byte b2= 128;
		
		System.out.println(Byte.MAX_VALUE);//127
		System.out.println(Byte.MIN_VALUE);//-128

		System.out.println(Short.MAX_VALUE);//32767
		System.out.println(Short.MIN_VALUE);//-32768

		System.out.println(Integer.MAX_VALUE);//2147483647

		System.out.println(Integer.MIN_VALUE);//-2147483648

		
		
		int p1=2147483647;
		
		//int p2=2147483648;
		long p2=2147483648L;
		
		
		

		
		
	}
}
