
public class BankMain {

	public static void main(String[] args) {
		bank bank1=new bank("s kumar", "sbi", 5666565);
		System.out.println(bank1);
	
	}
}
