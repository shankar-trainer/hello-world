package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int addrId;
	private String addrCity;
	private String addrState;
	
	public int getAddrId() {
		return addrId;
	}



	public void setAddrId(int addrId) {
		this.addrId = addrId;
	}



	public String getAddrCity() {
		return addrCity;
	}



	public void setAddrCity(String addrCity) {
		this.addrCity = addrCity;
	}



	public String getAddrState() {
		return addrState;
	}



	public void setAddrState(String addrState) {
		this.addrState = addrState;
	}



	@Override
	public String toString() {
		return "Address [addrId=" + addrId + ", addrCity=" + addrCity + ", addrState=" + addrState + "]";
	}

}