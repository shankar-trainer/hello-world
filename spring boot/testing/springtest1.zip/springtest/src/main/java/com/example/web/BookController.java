package com.example.web;

import com.example.exception.BookException;
import com.example.model.Book;
import com.example.service.BookService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/book")
@Slf4j
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        try {
            //return ResponseEntity.ok(bookService.getAllBooks());
            return new ResponseEntity<>(bookService.getAllBooks(), HttpStatus.OK);
        } catch (BookException e) {
//         return ResponseEntity.notFound(e.getMessage()).build();
            return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/add")

    public ResponseEntity<Book> addBooks(Book b) {
        try {
        log.info("addBook  controller",b);
            return new ResponseEntity<>(bookService.addBooks(b), HttpStatus.OK);
        } catch (BookException e) {
            return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);

        }
    }

}
