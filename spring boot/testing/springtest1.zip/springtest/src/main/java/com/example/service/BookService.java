package com.example.service;

import com.example.dao.BookRepository;
import com.example.exception.BookException;
import com.example.model.Book;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public List<Book> getAllBooks() {
        log.info("findall service ");

        if(bookRepository.findAll().size()==0)
            throw new BookException("list is empty");
        else
        return bookRepository.findAll();
    }

    public Book addBooks(Book b) {
//        if(bookRepository.findById(b.getIsbn())!=null)
//            throw new BookException("is already ");
//        else
      log.info("addBook service ",b);
        return bookRepository.save(b);
    }


}
