package com.example.web;

import com.example.model.Book;
import com.example.service.BookService;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest(BookController.class)
//@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)

public class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookService bookService;

    @Test
    void getAllBook() throws Exception {
        Book book[]=new Book[]{
                Book.builder().bname("spring for dummies").cost(1200.0f).build(),
                Book.builder().bname("spring for professional").cost(1100).build(),
                Book.builder().bname("spring for beginners").cost(1240).build(),
                Book.builder().bname("spring in action").cost(1500).build(),
                Book.builder().bname("spring for ejb developer").cost(1700).build(),
        };

        Stream.of(book).forEach(book1->bookService.addBooks(book1));

        List<Book> bookList= Arrays.asList(book);

        when(bookService.getAllBooks()).thenReturn(bookList);
        mockMvc.perform(MockMvcRequestBuilders.get("/book")).
                andExpect(MockMvcResultMatchers.status().isOk()).
                andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON)).
                andExpect(jsonPath("$", Matchers.hasSize(5))).
                andExpect(jsonPath("$[0].bname").value("spring for dummies")).
                andExpect(jsonPath("$[0].cost").value(Float.valueOf(1200.0f)));
    }
}
//mvn test -Dtest=com.example.web.BookControllerTest#getAllBook