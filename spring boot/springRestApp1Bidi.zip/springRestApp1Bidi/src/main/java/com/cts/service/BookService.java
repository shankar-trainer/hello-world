package com.cts.service;

import com.cts.dao.AuthorRepository;
import com.cts.dao.BookRepository;
import com.cts.dao.ChapterRepository;
import com.cts.exception.BookException;
import com.cts.model.Author;
import com.cts.model.Book;
import com.cts.model.Chapters;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
@Slf4j
public class BookService {
    @Autowired
    private BookRepository bookRepository;
    @Autowired
    private AuthorRepository authorRepository;

    @Autowired
    ChapterRepository chapterRepository;

    // @Transactional
    public Chapters addChapters(Chapters chapters) {
//        Book book = chapters.getBook();
//        bookRepository.save(book);
//        chapters.setBook(book);
        return chapterRepository.save(chapters);
    }

//
//    public Chapters addChapters(Chapters chapters) {
//        Book book = chapters.getBook();
//        book.getChaptersSet().add(chapters);
//        return chapterRepository.save(chapters);
//    }


    public Book addBook(Book b) {
        for (Chapters c : b.getChaptersSet())
            c.setBook(b);
        return bookRepository.save(b);
    }

    public Author addAuthor(Author author) {
        Book book = author.getBook();
        book.setAuthor(author);
        return authorRepository.save(author);
    }


    public Book updateBook(Book b) {
        Optional<Book> byId = bookRepository.findById(b.getIsbn());
        if (byId.isPresent()) {
            return bookRepository.save(b);
        } else
            throw new BookException("book not present with isbn " + b.getIsbn());
    }

    public List<Book> getAllBook() {
        if (bookRepository.findAll().size() == 0)
            throw new BookException("book list is empty ");
        else
            return bookRepository.findAll();
    }

    public Book searchBookById(long id) {
        Optional<Book> byId = bookRepository.findById(id);
        if (byId.isEmpty())
            throw new BookException("book not present with isbn " + id);
        return bookRepository.findById(id).get();
    }

    public Book deleteBookById(long id) {
        Book b1;
        Optional<Book> byId = bookRepository.findById(id);
        if (byId.isEmpty())
            throw new BookException("book not present with isbn " + id);
        else {
            b1 = byId.get();
            bookRepository.deleteById(id);
        }
        return b1;
    }


}
