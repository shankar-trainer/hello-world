package com.example.SpringBootJpa1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpa1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
