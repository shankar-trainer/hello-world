package com.tvscredit.error;

public class BookException  extends Exception {
	public BookException(String s) {
		super(s);
	}

}
