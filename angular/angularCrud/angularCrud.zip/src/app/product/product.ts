export class Product {
 id:number=0;
 name:string='';
 cost:number=0;

}
