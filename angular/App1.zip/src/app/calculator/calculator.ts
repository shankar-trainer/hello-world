export class Calculator {
    n1:number;
    n2:number;
    addition:number;
    subtraction:number;
    multiplication:number;
    division:number;
    constructor(){
        this.n1=0;
        this.n2=0
        this.addition=0;
        this.subtraction=0;
        this.multiplication=0;
        this.division=0;
    }
}
