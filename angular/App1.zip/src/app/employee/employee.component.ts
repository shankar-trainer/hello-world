import { Component } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent {

  empid:number;
  empname:string;
  empsalary:number;
  empdob:Date;

  constructor(){
    this.empid=788787;
    this.empname='aman kumar';
    this.empsalary=89000;
    this.empdob=new Date('10-12-2009');
  }

}
