export class User {

    userid:number;
    username:string;
    userlocation:string;
    userdob:string;

    constructor(){
        this.userdob='';
        this.username='';
        this.userlocation='';
        this.userid=0;
    }


}
