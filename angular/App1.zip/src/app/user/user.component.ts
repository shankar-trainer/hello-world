import { Component } from '@angular/core';
import { User } from './user';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {
  user: User;
user1: User[];
img1:string;
imgwidth:number;
imgheight:number;

userClick(){
 // console.log('user click called ')
  alert("User Information  "+JSON.stringify(this.user))
  alert('Id is '+this.user.userid+"\n"+'name is '+this.user.username+"\n"+'Location is '+this.user.userlocation+"\n"+'DOB is '+this.user.userdob+"\n")
}


   constructor() {
     this.img1='https://cdn.pixabay.com/photo/2015/04/19/08/32/marguerite-729510__340.jpg';
     this.imgwidth=200;
     this.imgheight=150
     this.user = {
      "userid": 10001,
      "username": 'mohan kumatr',
      "userlocation": 'delhi',
      "userdob": '10-10-2000'
    };

    this.user1 = [
      {
        "userid": 80001,
        "username": 'vimal kumar',
        "userlocation": 'delhi',
        "userdob": '10-10-2000'
      },
      {
        "userid": 80002,
        "username": 'anand kumar',
        "userlocation": 'viratnagar',
        "userdob": '10-10-2000'
      },
      {
        "userid": 80003,
        "username": 'sameer kumar',
        "userlocation": 'janakpur',
        "userdob": '10-10-2000'
      },
      {
        "userid": 80004,
        "username": 'kamal kumar',
        "userlocation": 'kathmandu',
        "userdob": '10-10-2000'
      },
      {
        "userid": 10001,
        "username": 'mahendra kumatr',
        "userlocation": 'patna',
        "userdob": '10-10-2000'
      }

    ]

  }

}
