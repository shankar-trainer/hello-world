#include<stdio.h>
#include<string.h>

int main()
{
	
	char name[12];
	
	   printf("enter name ");
	   gets(name);
	   printf("name  is %s",name);
}
	   
	   